<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="max-w-3xl mx-auto mt-8 bg-white p-6 rounded-lg shadow">
        <h2 class="text-2xl font-bold mb-4">Unit Details</h2>

        <div class="mb-4">
            <strong>Unit Name:</strong> <?php echo e($unit->unit_name); ?>

        </div>
        <div class="mb-4">
            <strong>Description:</strong> <?php echo e($unit->description); ?>

        </div>
        <div class="mb-4">
            <strong>Price:</strong> <?php echo e($unit->currency); ?> <?php echo e(number_format($unit->price, 2)); ?>

        </div>
        <div class="mb-4">
            <strong>Type:</strong> <?php echo e(ucfirst($unit->unit_type)); ?>

        </div>
        <div class="mb-4">
            <strong>Furnishing:</strong> <?php echo e(ucfirst($unit->furnishing)); ?>

        </div>
        <div class="mb-4">
    <strong>Status:</strong> 
   <span class="px-2 py-1 rounded text-white 
    <?php echo e($unit->status === 'available' 
        ? 'bg-green-500' 
        : ($unit->status === 'booked' 
            ? 'bg-blue-500' 
            : ($unit->status === 'unavailable' 
                ? 'bg-red-600' 
                : 'bg-gray-500'))); ?>">
    <?php echo e(ucfirst($unit->status ?? 'N/A')); ?>

</span>

</div>

        <div class="mb-4">
            <strong>Size:</strong> <?php echo e($unit->size_sqft); ?> sqft
        </div>
        <div class="mb-4">
            <strong>Furnished:</strong> <?php echo e($unit->furnished ? 'Yes' : 'No'); ?>

        </div>

        <div class="flex justify-between mt-6">
            <a href="<?php echo e(route('units.index')); ?>" 
               class="bg-gray-500 text-white px-4 py-2 rounded hover:bg-gray-600">
                Back to Units
            </a>
            <a href="<?php echo e(route('units.edit', $unit->id)); ?>" 
               class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">
                Edit Unit
            </a>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\estate\realestate-app\resources\views/units/show.blade.php ENDPATH**/ ?>