<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="max-w-4xl mx-auto py-8">
        <h1 class="text-2xl font-bold mb-4"><?php echo e($property->name); ?></h1>

        <div class="mb-4">
            <strong>Description:</strong>
            <p><?php echo e($property->description); ?></p>
        </div>

        <div class="mb-4">
            <strong>Type:</strong> <?php echo e(ucfirst($property->type)); ?>

        </div>

        <div class="mb-4">
            <strong>Status:</strong>
            <span class="px-2 py-1 rounded text-white
                <?php echo e($property->status === 'active' ? 'bg-green-500' : ($property->status === 'pending' ? 'bg-yellow-500' : 'bg-red-500')); ?>">
                <?php echo e(ucfirst($property->status)); ?>

            </span>
        </div>

        <div class="mb-4">
            <strong>City:</strong> <?php echo e($property->city); ?>

        </div>

        <div class="mb-4">
            <strong>Region:</strong> <?php echo e($property->region); ?>

        </div>

        <div class="mb-4">
            <strong>Address:</strong> <?php echo e($property->address); ?>

        </div>

        <div class="mb-4">
            <strong>Location:</strong>
            Lat: <?php echo e($property->latitude); ?> | Lng: <?php echo e($property->longitude); ?>

        </div>
        
        <!-- code to display map -->
         <div class="mb-6">
        <strong>Property Location:</strong>
        <?php if($property->latitude && $property->longitude): ?>
        <div id="property-map" style="height: 400px;" class="mt-3 rounded shadow"></div>
        <?php else: ?>
         <p>No location available for this property.</p>
        <?php endif; ?>
        </div>


        <div class="mb-4">
            <strong>Cover Image:</strong><br>
                <?php if($property->cover_image): ?>
                 <img src="<?php echo e(asset($property->cover_image)); ?>" alt="Cover" class="w-30 h-30 rounded object-cover">
                 <?php else: ?>
                  <span class="text-gray-500">No Image</span>
                <?php endif; ?>
        </div>

        <div class="flex space-x-4 mt-6">
            <a href="<?php echo e(route('properties.index')); ?>" 
               class="bg-gray-500 text-white px-4 py-2 rounded">Back</a>
            <a href="<?php echo e(route('properties.edit', $property->id)); ?>" 
               class="bg-blue-500 text-white px-4 py-2 rounded">Edit</a>
        </div>
    </div>


  <!-- scripts support map display -->
    <?php if($property->latitude && $property->longitude): ?>
<script>
    document.addEventListener("DOMContentLoaded", function () {
        var map = L.map('property-map').setView([<?php echo e($property->latitude); ?>, <?php echo e($property->longitude); ?>], 15);

        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; OpenStreetMap contributors'
        }).addTo(map);

        L.marker([<?php echo e($property->latitude); ?>, <?php echo e($property->longitude); ?>])
            .addTo(map)
            .bindPopup("<b><?php echo e($property->name); ?></b><br><?php echo e($property->address); ?>")
            .openPopup();
    });
</script>
<?php endif; ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\estate\realestate-app\resources\views/properties/show.blade.php ENDPATH**/ ?>