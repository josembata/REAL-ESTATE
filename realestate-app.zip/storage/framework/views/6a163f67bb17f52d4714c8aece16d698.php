<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="max-w-lg mx-auto p-6 bg-white shadow-md rounded-lg">
        <h2 class="text-xl font-bold mb-4">Edit Property</h2>

        <form action="<?php echo e(route('properties.update', $property)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="mb-4">
                <label class="block text-sm font-medium">Name</label>
                <input type="text" name="name" value="<?php echo e(old('name', $property->name)); ?>" class="w-full border rounded p-2" required>
            </div>

            <div class="mb-4">
                <label class="block text-sm font-medium">Description</label>
                <textarea name="description" class="w-full border rounded p-2"><?php echo e(old('description', $property->description)); ?></textarea>
            </div>

            <div class="mb-4">
                <label class="block text-sm font-medium">Type</label>
                <select name="type" class="w-full border rounded p-2" required>
                    <option value="house" <?php echo e($property->type == 'house' ? 'selected' : ''); ?>>House</option>
                    <option value="apartment" <?php echo e($property->type == 'apartment' ? 'selected' : ''); ?>>Apartment</option>
                    <option value="land" <?php echo e($property->type == 'land' ? 'selected' : ''); ?>>Land</option>
                    <option value="office" <?php echo e($property->type == 'office' ? 'selected' : ''); ?>>Office</option>
                </select>
            </div>

            <div class="mb-4">
                <label class="block text-sm font-medium">Status</label>
                <select name="status" class="w-full border rounded p-2" required>
                    <option value="active" <?php echo e($property->status == 'active' ? 'selected' : ''); ?>>Active</option>
                    <option value="pending" <?php echo e($property->status == 'pending' ? 'selected' : ''); ?>>Pending</option>
                    <option value="archived" <?php echo e($property->status == 'archived' ? 'selected' : ''); ?>>Archived</option>
                </select>
            </div>

                 <div class="mb-4">
    <label class="block text-sm font-medium">Region</label>
    <select name="region" id="region" class="w-full border rounded p-2" required>
        <option value="">Select Region</option>
        <?php
            $regions = [
                'Dar es Salaam' => ['Ilala','Kinondoni','Temeke'],
                'Dodoma' => ['Dodoma Urban','Chamwino'],
                'Arusha' => ['Arusha Urban','Meru'],
                'Mwanza' => ['Nyamagana','Ilemela'],
                'Mbeya' => ['Mbeya Urban','Rungwe'],
                'Kilimanjaro' => ['Moshi','Moshi Rural'],
                
            ];
        ?>

        <?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $regionName => $citiesArray): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($regionName); ?>" 
                <?php echo e(old('region', $property->region ?? '') == $regionName ? 'selected' : ''); ?>>
                <?php echo e($regionName); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>

<div class="mb-4">
    <label class="block text-sm font-medium">City</label>
    <select name="city" id="city" class="w-full border rounded p-2" required>
        <option value="">Select City</option>
        <?php if(old('region', $property->region ?? null)): ?>
            <?php $__currentLoopData = $regions[old('region', $property->region)]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($city); ?>" <?php echo e(old('city', $property->city ?? '') == $city ? 'selected' : ''); ?>>
                    <?php echo e($city); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </select>
</div>

            <div class="mb-4">
                <label class="block text-sm font-medium">Address</label>
                <input type="text" name="address" value="<?php echo e(old('address', $property->address)); ?>" class="w-full border rounded p-2" required>
            </div>

                     <div class="mb-6">
    <label for="latitude" class="block text-sm font-medium text-gray-700">Latitude</label>
    <input type="text" 
           id="latitude" 
           name="latitude" 
           value="<?php echo e(old('latitude', $property->latitude ?? '')); ?>" 
           class="w-full px-4 py-2 border rounded-md" 
           readonly>
</div>

<div class="mb-6">
    <label for="longitude" class="block text-sm font-medium text-gray-700">Longitude</label>
    <input type="text" 
           id="longitude" 
           name="longitude" 
           value="<?php echo e(old('longitude', $property->longitude ?? '')); ?>" 
           class="w-full px-4 py-2 border rounded-md" 
           readonly>
</div>

<div class="mb-6">
    <strong>Select Location on Map:</strong>
    <div id="map" style="height: 400px;" class="mt-3 rounded shadow"></div>
</div>

            <div class="mb-4">
                <label class="block text-sm font-medium">Cover Image</label>
                <input type="file" name="cover_image" class="w-full border rounded p-2">
                <?php if($property->cover_image): ?>
                    <div class="mt-2">
                        <img src="<?php echo e(asset($property->cover_image)); ?>" alt="Cover" class="w-24 h-24 rounded object-cover">
                    </div>
                <?php endif; ?>
            </div>

            <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded">
                Update Property
            </button>
        </form>
    </div>

    <script>
    document.addEventListener("DOMContentLoaded", function () {
        // Default location Dar es Salaam 
        var defaultLat = <?php echo e(old('latitude', $property->latitude ?? -6.7924)); ?>;
        var defaultLng = <?php echo e(old('longitude', $property->longitude ?? 39.2083)); ?>;

        var map = L.map('map').setView([defaultLat, defaultLng], 13);

        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; OpenStreetMap contributors'
        }).addTo(map);

        var marker = L.marker([defaultLat, defaultLng], {draggable: true}).addTo(map);

        // Update inputs when marker is dragged
        marker.on("dragend", function (e) {
            var lat = marker.getLatLng().lat.toFixed(6);
            var lng = marker.getLatLng().lng.toFixed(6);
            document.getElementById("latitude").value = lat;
            document.getElementById("longitude").value = lng;
        });

        // Update inputs when clicking on map
        map.on("click", function (e) {
            var lat = e.latlng.lat.toFixed(6);
            var lng = e.latlng.lng.toFixed(6);
            marker.setLatLng([lat, lng]);
            document.getElementById("latitude").value = lat;
            document.getElementById("longitude").value = lng;
        });
    });
</script>

<!-- scripts for region and city -->
<script>
document.addEventListener("DOMContentLoaded", function() {
    const regions = <?php echo json_encode($regions, 15, 512) ?>; // Pass PHP array to JS
    const regionSelect = document.getElementById('region');
    const citySelect = document.getElementById('city');

    regionSelect.addEventListener('change', function() {
        const selectedRegion = this.value;

        // Clear current city options
        citySelect.innerHTML = '<option value="">Select City</option>';

        if (selectedRegion && regions[selectedRegion]) {
            regions[selectedRegion].forEach(function(city) {
                const option = document.createElement('option');
                option.value = city;
                option.text = city;
                citySelect.appendChild(option);
            });
        }
    });
});
</script>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\estate\realestate-app\resources\views/properties/edit.blade.php ENDPATH**/ ?>