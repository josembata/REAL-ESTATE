<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Admin Dashboard')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                <!-- Admin Stats -->
                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6">
                    <h3 class="text-lg font-semibold mb-4">Users Management</h3>
                    <p class="text-3xl font-bold text-blue-600"><?php echo e(App\Models\User::count()); ?></p>
                    <p>Total Users</p>
                    <a href="<?php echo e(route('admin.users.index')); ?>" class="text-blue-600 hover:text-blue-800 mt-2 inline-block">
                        Manage Users 
                    </a>
                </div>

                 <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6">
                    <h3 class="text-lg font-semibold mb-4">Customer</h3>
                    <p class="text-3xl font-bold text-green-600"><?php echo e(App\Models\User::where('role', 'customer')->count()); ?></p>
                    <p>Customer</p>
                </div>

                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6">
                    <h3 class="text-lg font-semibold mb-4">Agents</h3>
                    <p class="text-3xl font-bold text-green-600"><?php echo e(App\Models\User::where('role', 'agent')->count()); ?></p>
                    <p>Total Agents</p>
                </div>

                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6">
                    <h3 class="text-lg font-semibold mb-4">Landlords</h3>
                    <p class="text-3xl font-bold text-purple-600"><?php echo e(App\Models\User::where('role', 'landlord')->count()); ?></p>
                    <p>Total Landlords</p>
                </div>
            </div>

            <div class="mt-8 bg-white overflow-hidden shadow-sm sm:rounded-lg p-6">
                
                <div class="flex space-x-4">
                    <a href="<?php echo e(route('admin.users.index')); ?>" class="bg-blue-500 hover:bg-blue-700 text-white px-4 py-2 rounded">
                        Manage Users
                    </a>
                    <a href="#" class="bg-green-500 hover:bg-green-700 text-white px-4 py-2 rounded">
                        View Reports
                    </a>
                    <a href="#" class="bg-purple-500 hover:bg-purple-700 text-white px-4 py-2 rounded">
                        System Settings
                    </a>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH D:\estate\realestate-app\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>