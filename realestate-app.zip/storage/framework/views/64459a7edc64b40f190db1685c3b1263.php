<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="max-w-3xl mx-auto mt-8">
        <h2 class="text-2xl font-bold mb-6">Edit Unit</h2>

        <form method="POST" action="<?php echo e(route('units.update', $unit)); ?>" class="space-y-6">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div>
                <label class="block text-sm font-medium mb-2">Property</label>
                <select name="property_id" required class="w-full border p-2 rounded">
                    <?php $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($property->id); ?>" <?php echo e($unit->property_id == $property->id ? 'selected' : ''); ?>>
                            <?php echo e($property->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div>
                <label class="block text-sm font-medium mb-2">Unit Name</label>
                <input type="text" name="unit_name" value="<?php echo e($unit->unit_name); ?>" class="w-full border p-2 rounded" required>
            </div>

            <div>
                <label class="block text-sm font-medium mb-2">Description</label>
                <textarea name="description" rows="3" class="w-full border p-2 rounded"><?php echo e($unit->description); ?></textarea>
            </div>

            <div class="grid grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-medium mb-2">Price</label>
                    <input type="number" step="0.01" name="price" value="<?php echo e($unit->price); ?>" class="w-full border p-2 rounded" required>
                </div>
                <div>
                    <label class="block text-sm font-medium mb-2">Currency</label>
                    <input type="text" name="currency" value="<?php echo e($unit->currency); ?>" class="w-full border p-2 rounded" required>
                </div>
            </div>

            <div>
                <label class="block text-sm font-medium mb-2">Unit Type</label>
                <select name="unit_type" required class="w-full border p-2 rounded">
                    <option value="single" <?php echo e($unit->unit_type == 'single' ? 'selected' : ''); ?>>Single</option>
                    <option value="double" <?php echo e($unit->unit_type == 'double' ? 'selected' : ''); ?>>Double</option>
                    <option value="suite" <?php echo e($unit->unit_type == 'suite' ? 'selected' : ''); ?>>Suite</option>
                    <option value="office" <?php echo e($unit->unit_type == 'office' ? 'selected' : ''); ?>>Office</option>
                </select>
            </div>

            <div>
                <label class="block text-sm font-medium mb-2">Furnishing</label>
                <select name="furnishing" class="w-full border p-2 rounded">
                    <option value="unfurnished" <?php echo e($unit->furnishing == 'unfurnished' ? 'selected' : ''); ?>>Unfurnished</option>
                    <option value="partially_furnished" <?php echo e($unit->furnishing == 'partially_furnished' ? 'selected' : ''); ?>>Partially Furnished</option>
                    <option value="furnished" <?php echo e($unit->furnishing == 'furnished' ? 'selected' : ''); ?>>Furnished</option>
                </select>
            </div>

            <div>
                <label class="block text-sm font-medium mb-2">Size (sqft)</label>
                <input type="number" name="size_sqft" value="<?php echo e($unit->size_sqft); ?>" class="w-full border p-2 rounded">
            </div>

            <div class="flex items-center">
                <input type="checkbox" name="furnished" value="1" <?php echo e($unit->furnished ? 'checked' : ''); ?> class="mr-2">
                <span>Is Furnished?</span>
            </div>

            <div>
                <label class="block text-sm font-medium mb-2">Status</label>
                <select name="status" required class="w-full border p-2 rounded">
                    <option value="available" <?php echo e($unit->status == 'available' ? 'selected' : ''); ?>>Available</option>
                    <option value="booked" <?php echo e($unit->status == 'booked' ? 'selected' : ''); ?>>Booked</option>
                    <option value="unavailable" <?php echo e($unit->status == 'unavailable' ? 'selected' : ''); ?>>Unavailable</option>
                </select>
            </div>

            <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded-lg">
                Update Unit
            </button>
        </form>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\estate\realestate-app\resources\views/units/edit.blade.php ENDPATH**/ ?>