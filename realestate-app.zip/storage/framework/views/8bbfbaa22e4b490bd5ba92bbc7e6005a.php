<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="max-w-6xl mx-auto mt-8">
        <h2 class="text-2xl font-bold mb-6">Units List</h2>

        <a href="<?php echo e(route('units.create')); ?>" 
           class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">
            + Add Unit
        </a>

        <table class="w-full mt-6 border border-gray-200 shadow-sm">
            <thead class="bg-gray-100">
                <tr>
                    <th class="p-3 text-left">Unit Name</th>
                    <th class="p-3 text-left">Property</th>
                    <th class="p-3 text-left">Type</th>
                    <th class="p-3 text-left">Price</th>
                    <th class="p-3 text-left">Status</th>
                    <th class="p-3 text-center">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="border-t">
                        <td class="p-3"><?php echo e($unit->unit_name); ?></td>
                        <td class="p-3"><?php echo e($unit->property->name); ?></td>
                        <td class="p-3"><?php echo e(ucfirst($unit->unit_type)); ?></td>
                        <td class="p-3"><?php echo e($unit->price); ?> <?php echo e($unit->currency); ?></td>
                        <td class="p-3">
                          <span class="px-2 py-1 rounded text-white 
                     <?php echo e($unit->status === 'available' 
                    ? 'bg-green-500' 
                   : ($unit->status === 'booked' 
                     ? 'bg-blue-500' 
                     : ($unit->status === 'unavailable' 
                    ? 'bg-red-600' 
                     : 'bg-gray-500'))); ?>">
                     <?php echo e(ucfirst($unit->status ?? 'N/A')); ?>

                    </span>

                        </td>
                        <td class="px-4 py-2 border">
                        <a href="<?php echo e(route('units.show', $unit->id)); ?>" 
                        class="bg-green-500 text-white px-3 py-1 rounded hover:bg-green-600">
                         View
                        </a>
                        <a href="<?php echo e(route('units.edit', $unit->id)); ?>" 
                         class="bg-blue-500 text-white px-3 py-1 rounded hover:bg-blue-600">
                         Edit
                          </a>
                         <form action="<?php echo e(route('units.destroy', $unit->id)); ?>" method="POST" class="inline">
                         <?php echo csrf_field(); ?>
                         <?php echo method_field('DELETE'); ?>
                        <button type="submit" 
                         
                         onclick="return confirm('Are you sure you want to delete this unit?')"
                          class="bg-red-600 hover:bg-red-700 text-white px-3 py-1 rounded">
                          Delete
                          </button>
                          </form>
                         </td>

                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <div class="mt-4">
            <?php echo e($units->links()); ?>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\estate\realestate-app\resources\views/units/index.blade.php ENDPATH**/ ?>