<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="max-w-5xl mx-auto p-6 bg-white shadow-md rounded-lg">
        <div class="flex justify-between items-center mb-6">
            <h2 class="text-xl font-bold">All Properties</h2>
            <a href="<?php echo e(route('properties.create')); ?>" 
               class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition">
                 Add Property
            </a>
        </div>

        <?php if(session('success')): ?>
            <div class="mb-4 p-3 bg-green-100 text-green-700 rounded">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <table class="w-full border-collapse border border-gray-300">
            <thead>
                <tr class="bg-gray-100">
                    <th class="border border-gray-300 px-4 py-2">#</th>
                    <th class="border border-gray-300 px-4 py-2">Name</th>
                    <th class="border border-gray-300 px-4 py-2">Type</th>
                    <th class="border border-gray-300 px-4 py-2">Status</th>
                    <th class="border border-gray-300 px-4 py-2">City</th>
                    <th class="border border-gray-300 px-4 py-2">Region</th>
                    <th class="border border-gray-300 px-4 py-2">Image</th>
                    <th class="border border-gray-300 px-4 py-2">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="border border-gray-300 px-4 py-2"><?php echo e($index + 1); ?></td>
                        <td class="border border-gray-300 px-4 py-2"><?php echo e($property->name); ?></td>
                        <td class="border border-gray-300 px-4 py-2 capitalize"><?php echo e($property->type); ?></td>
                          <td class="p-3">
                          <span class="px-2 py-1 rounded text-white 
                     <?php echo e($property->status === 'active' 
                    ? 'bg-green-500' 
                   : ($property->status === 'archived' 
                     ? 'bg-blue-500' 
                     : ($property->status === 'pending' 
                    ? 'bg-red-600' 
                     : 'bg-gray-500'))); ?>">
                     <?php echo e(ucfirst($property->status ?? 'N/A')); ?>

                    </span>

                        </td>
                        <td class="border border-gray-300 px-4 py-2"><?php echo e($property->city); ?></td>
                        <td class="border border-gray-300 px-4 py-2"><?php echo e($property->region); ?></td>
                        <td class="border border-gray-300 px-4 py-2">
                            <?php if($property->cover_image): ?>
                                <img src="<?php echo e(asset($property->cover_image)); ?>" alt="Cover" class="w-16 h-16 rounded object-cover">
                            <?php else: ?>
                                <span class="text-gray-500">No Image</span>
                            <?php endif; ?>
                        </td>
                        <td class="border border-gray-300 px-4 py-2 flex space-x-2">
                            <a href="<?php echo e(route('properties.show', $property->id)); ?>" 
                             class="bg-green-500 text-white px-3 py-1 rounded">
                             View</a>

                            <a href="<?php echo e(route('properties.edit', $property)); ?>" 
                               class="bg-blue-600 text-white px-3 py-1 rounded hover:bg-yellow-600 transition">
                                Edit
                            </a>
                            <form action="<?php echo e(route('properties.destroy', $property)); ?>" method="POST" onsubmit="return confirm('Are you sure?');">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="bg-red-600 text-white px-3 py-1 rounded hover:bg-red-700 transition">
                                    Delete
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="8" class="text-center py-4 text-gray-500">No properties found</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\estate\realestate-app\resources\views/properties/index.blade.php ENDPATH**/ ?>